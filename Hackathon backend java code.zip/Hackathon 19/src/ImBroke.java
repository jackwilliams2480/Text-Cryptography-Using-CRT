import java.util.*;

public class ImBroke {

  public static void main(String[] args) {
    @SuppressWarnings("resource")
    Scanner scnr = new Scanner(System.in);
    System.out.println("Enter Bank Account Number:");
    String bnu = scnr.nextLine();
    BankAcc ba = new BankAcc();
    boolean loop1 = true;
    boolean loop2 = true;
    do {
      if (bnu.equals(ba.AccNum)) {
        System.out.println("Enter Username:");
        String user = scnr.nextLine();
        System.out.println("Enter Password:");
        String pass = scnr.nextLine();
        while (loop2) {
          if (user.equals(ba.user) && pass.equals(ba.password)) {
            String selection = "";
            System.out.println("\n\n\nYour balance is : "+ba.balance);
            System.out.println("\t1.Groceries\n\t2.Dining\n\t3.School Supplies\n\t4.Recreation");
            System.out.println("Pick any categories you want (eg: enter \"1 2 4\")");
            selection = scnr.nextLine();
            contains(selection, ba);
            display(ba);
            loop1=false;
            loop2=false;
            } else {
            System.out.println("invalid username or password, type again or enter finish for both to exit");
            System.out.println("Enter Username:");
            user = scnr.nextLine();
            System.out.println("Enter Password:");
            pass = scnr.nextLine();
            if (user.equals("finish") || pass.equals("finish")) {
              loop1=false;
              loop2=false;
            }
              
          }
        }

      } else {
        System.out.println("invalid bank account number, type again or enter 0 to exit");
        System.out.println("Enter Bank Account Number:");
        bnu = scnr.nextLine();
        if (bnu.equals("0"))
          loop1 = false;
      }
    } while (loop1);

  }

  public static double update(double num, BankAcc bank) {
    double n = 0;
    n = (num / 100) * (bank.balance);
    return n;
  }
  
  public static void contains(String selection, BankAcc bank) {
    double groc,dine,supp,rec;
    groc = 0; dine = 0; supp = 0; rec = 0;
    @SuppressWarnings("resource")
    Scanner scnr = new Scanner(System.in);
    for (int i = 0; i<selection.length(); i++) {
      if(selection.charAt(i)=='1') {
        System.out.println("Enter how much % do you want to spend on groceries");
        groc = scnr.nextDouble();
        bank.setGroc(update(groc, bank));
      }
      else if (selection.charAt(i)=='2') {
        System.out.println("Enter how much % do you want to spend on Dining");
        dine = scnr.nextDouble();
        bank.setDine(update(dine, bank));
      }
      else if (selection.charAt(i)=='3') {
        System.out.println("Enter how much % do you want to spend on School Supplies");
        supp = scnr.nextDouble();
        bank.setSupp(update(supp, bank));
      }
      else if (selection.charAt(i)=='4') {
        System.out.println("Enter how much % do you want to spend on Recreation");
        rec = scnr.nextDouble();
        bank.setRec(update(rec, bank));
      }
      if (!((groc+dine+supp+rec)<=100)) {
        System.out.println("You have entered more than 100% spending :( \nenter spendings again.");
        i--;
      }
    }
    bank.setSavings();
  }
  
  public static void display(BankAcc bank) {
    System.out.println("\t\tGroceries spendings : " + bank.getGroc()+"$");
    System.out.println("\t\tDining spendings : " + bank.getDine()+"$");
    System.out.println("\t\tSchool Supplies spendings : " + bank.getSupp()+"$");
    System.out.println("\t\tRecreation spendings : " + bank.getRec()+"$");
    System.out.println("You will save : " + bank.getSavings() + "$\tor :" + (bank.getSavings()/bank.getBal()*100)+"%");
  }
}
