
public class BankAcc {

  public String AccNum;
  public double balance;
  public String user;
  public String password;
  private double grocSaving;
  private double dineSaving;
  private double recSaving;
  private double suppSaving;
  private double Tsavings;

  public BankAcc() {
    AccNum = "694206942069";
    balance = 1000;
    user = "JohnSmith";
    password = "12345678";
  }
  
  public void setGroc(double num) {
    grocSaving = num;
  }
  public void setDine(double num) {
    dineSaving = num;
  }
  public void setRec(double num) {
    recSaving = num;
  }
  public void setSupp(double num) {
    suppSaving = num;
  }
  public void setSavings() {
    Tsavings = balance - grocSaving - dineSaving - recSaving - suppSaving;
  }
  public double getGroc() {
    return(grocSaving);
  }
  public double getBal() {
    return(balance);
  }
  
  public double getDine() {
    return(dineSaving);
  }
  
  public double getRec() {
    return(recSaving);
  }
  
  public double getSupp() {
    return(suppSaving);
  }
  
  public double getSavings() {
    return(Tsavings);
  }

}
